import streamlit as st 
import pandas as pd
import os
from Components import file_uploader

if not st.session_state.get('years'):
  st.session_state.years = {}

st.set_page_config(page_title='TNEA Compare')

st.title('Seat Matrix Comparison PDF Uploads')

col1, col2 = st.columns(2)

with col1:
  file_uploader('Upload SeatMatrix **{}** th Year', 'a', 'N-1')
with col2:
  file_uploader('Upload SeatMatrix **{}** th Year', 'b', 'N')