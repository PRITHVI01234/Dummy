import logging

import mlflow
import numpy as np
import pandas as pd
from model.evaluation import accuracy
from sklearn.base import RegressorMixin
from typing_extensions import Annotated
from zenml import step
from zenml.client import Client

experiment_tracker = Client().active_stack.experiment_tracker
from typing import Tuple


@step(experiment_tracker=experiment_tracker.name)
def evaluation(
    model: RegressorMixin, x_test: pd.DataFrame, y_test: pd.Series
) -> Tuple[Annotated[float, "Accuracy"]]:

    """
    Args:
        model: RegressorMixin
        x_test: pd.DataFrame
        y_test: pd.Series
    Returns:
        accuracy: float
    """
    try:

        prediction = model.predict(x_test)
        accuracy_class = accuracy()
        accuracy = accuracy.calculate_score(y_test, prediction)
        mlflow.log_metric("Accuracy", accuracy)
        
        return accuracy
    
    except Exception as e:
        logging.error(e)
        raise e