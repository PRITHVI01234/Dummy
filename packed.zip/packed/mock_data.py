import csv
import time
import random

def generate_random_numbers(filename, num_values):
    # Open the file in write mode
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Timestamp', 'RandomNumber'])  # Write the header

        for _ in range(num_values):
            timestamp = time.strftime('%Y-%m-%d %H:%M:%S')  # Get the current time
            random_number = random.randint(0, 100)  # Generate a random number
            writer.writerow([timestamp, random_number])  # Write to the CSV file
            time.sleep(1)  # Wait for 1 second

if __name__ == "__main__":
    generate_random_numbers('random_numbers.csv', 1000)
