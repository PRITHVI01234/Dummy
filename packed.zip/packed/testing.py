import requests
import time
from kafka import KafkaProducer
import json

# Kafka setup
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',  # Change this to your Kafka server
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

url = "https://d92c-2409-4072-317-da71-6558-a652-ff59-822.ngrok-free.app/generate_data"

#while True:
num_rows = 1
params = {'num_rows': num_rows}  # Specify the number of rows you want

response = requests.get(url, params=params)

if response.status_code == 200:
    data = response.json()
    print("Generated data:")
    print(data)

    # Send data to Kafka topics
    for row in data:
        producer.send('current', {'current': row['current']})
        producer.send('voltage', {'voltage': row['voltage']})
        producer.send('phase_angle', {'phase_angle': row['phase_angle']})

else:
    print("Failed to fetch data. Status code:", response.status_code)

time.sleep(1)  # Wait for 1 second before the next request
