from flask import Flask, jsonify, request
import numpy as np
import time

app = Flask(__name__)

@app.route('/generate_data', methods=['GET'])
def generate_data():
    # Get the number of rows from the query parameters, default to 1 if not provided
    num_rows = int(request.args.get('num_rows', 10))

    data_list = []

    for i in range(num_rows):
        # Generate random data for current (in Amperes)
        current = np.random.uniform(low=0, high=100)

        # Generate random data for voltage (in Volts)
        voltage = np.random.uniform(low=0, high=230)

        # Generate random data for phase angle (in degrees)
        phase_angle = np.random.uniform(low=-180, high=180)

        # Append the data to the list
        data_list.append({
            'current': current,
            'voltage': voltage,
            'phase_angle': phase_angle
        })

        time.sleep(0.5)

    return jsonify(data_list)

if __name__ == '__main__':
    app.run(port=7777)
