import numpy as np
import time
import math
from datetime import datetime
import streamlit as st
import plotly.graph_objs as go
from collections import deque
import cmath
import joblib
import json
import pywt
import multiprocessing
import matplotlib.pyplot as plt
import altair as alt
import pandas as pd
import google.generativeai as genai
import threading
from queue import Queue
from datetime import datetime, timedelta
import re
import pydeck as pdk
import random
import time
import requests
import aiohttp
import asyncio
from aiohttp import ClientSession
import threading
from queue import Queue
import queue

session = None
GOGO = False
iteration_count = 0
reset_threshold = 2000
bless = 0
blessed = 0
test_case_1 = False
test_case_2 = False

# FastAPI endpoint URLs
api_url = "http://127.0.0.1:8000/send_message"
receive_url = "http://127.0.0.1:8000/receive_message/app_a"
clear_url = "http://127.0.0.1:8000/clear_messages/app_a"

requests.post(clear_url)

def create_html_report(report_text):
    html_template = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Power System Analysis Report</title>
        <style>
            body {{
                font-family: 'Cambria Math', serif;
                line-height: 1.6;
                color: #333;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
            }}
            h1 {{
                color: #2c3e50;
                border-bottom: 2px solid #3498db;
                padding-bottom: 10px;
            }}
            h2 {{
                color: #2980b9;
                margin-top: 30px;
            }}
            h3 {{
                color: #3498db;
                margin-top: 20px;
            }}
            .section {{
                background-color: #f9f9f9;
                border-left: 4px solid #3498db;
                padding: 10px 20px;
                margin-bottom: 20px;
            }}
            .bold {{
                font-weight: bold;
                color: #e74c3c;
            }}
            .recommendation {{
                background-color: #eafaf1;
                border-left: 4px solid #2ecc71;
                padding: 10px 20px;
                margin-top: 10px;
            }}
            .subheading {{
                font-weight: bold;
                color: #34495e;
            }}
            ul {{
                list-style-type: disc;
                margin-left: 20px;
            }}
            .bullet {{
                margin-bottom: 10px;
            }}
        </style>
    </head>
    <body>
        <h1>Power System Analysis Report</h1>
        {content}
    </body>
    </html>
    """

    # Replace ** with {{bold}} as a placeholder for bold text
    report_text = report_text.replace('**', '{{bold}}')

    # Split the report into sections
    sections = report_text.split('\n\n')
    formatted_sections = []

    for section in sections:
        lines = section.split('\n')
        formatted_lines = []

        for line in lines:
            # Replace {{bold}} placeholder with HTML bold tag
            line = line.replace('{{bold}}', '<span class="bold">').replace('{{bold}}', '</span>')

            if line.startswith('###'):
                # This is a subheading
                formatted_lines.append(f"<h3 class='subheading'>{line[4:]}</h3>")
            elif line.startswith('##'):
                # This is a main section
                formatted_lines.append(f"<h2>{line[3:]}</h2>")
            elif line.startswith('1.') or line.startswith('2.') or line.startswith('3.'):
                # This is a numbered list item
                formatted_lines.append(f"<p class='bold'>{line}</p>")
            elif line.startswith('-'):
                # This is a bullet point
                formatted_lines.append(f"<li class='bullet'>{line[2:]}</li>")
            else:
                # Regular paragraph
                formatted_lines.append(f"<p>{line}</p>")

        # Combine formatted lines for this section
        formatted_section = "<div class='section'>"
        formatted_section += "<ul>" + "\n".join(formatted_lines) + "</ul>" if any(line.startswith('-') for line in lines) else "\n".join(formatted_lines)
        formatted_section += "</div>"

        formatted_sections.append(formatted_section)

    content = "\n".join(formatted_sections).replace('\n', '')
    return html_template.format(content=content)

@st.dialog(title="⚠️ WARNING !!! ⚠️",width='large')
def pop_up_warning():
    st.markdown(
        """
        <style>
        .warning-title {
            font-size: 40px;
            font-weight: bold;
            color: red;
            text-align: center;
        }
        .warning-text {
            font-size: 25px;
            font-weight: bold;
            color: black;
            text-align: center;
            background-color: #c59f2b;
            padding: 12px;
            border-radius: 10px;
        }
        .action-text {
            font-size: 20px;
            font-weight: bold;
            color: white;
            text-align: center;
            background-color: red;
            padding: 16px;
            border-radius: 10px;
            margin-top: 20px;
            margin-bottom: 20px;
        }
        </style>
        """, unsafe_allow_html=True)

    st.markdown("<div class='warning-title'>⚠️ EMERGENCY ALERT ⚠️</div>", unsafe_allow_html=True)
    st.markdown("<div class='warning-text'>There appears to be an emergency at the neighboring substation.</div>", unsafe_allow_html=True)
    st.markdown("<div class='action-text'>Please assess the situation immediately and take appropriate action!</div>", unsafe_allow_html=True)

   # st.error("This is a critical warning that requires immediate attention!", icon="🚨")
    st.warning("Failure to respond could lead to serious consequences.", icon="⚠️")
    st.info("Check the control room for more detailed information.", icon="ℹ️")

async def initialize_session():
    global session
    session = ClientSession()

async def close_session():
    global session
    if session:
        await session.close()

async def send_message(message):
    global session
    async with session.post(api_url, json=message) as response:
        return await response.json()

async def receive_message():
    global session
    async with session.get(receive_url) as response:
        return await response.json()

ohoh = False
async def handle_fault_detection(major_fault, trip_command, potential_fault):
    malinga = None
    global ohoh
    if np.any(major_fault):
        status_holder_V.error("Major fault detected: Sending tripping and warning commands to nearby substations.")
        status_holder_I.error("Major fault detected: Sending tripping and warning commands to nearby substations.")
        await send_message({
            'to_app': 'app_b',
            'message': "Critical fault detected in Substation A, initiating emergency trip commands."
        })
        malinga = 3
    elif np.any(trip_command):
        status_holder_V.warning("Trip Commands: Sending to peer substations.")
        status_holder_I.warning("Trip Commands: Sending to peer substations.")
        await send_message({
            'to_app': 'app_b',
            'message': "An Fault Has Been Detected in Substation A. Tripping action is recommended"
        })
        malinga = 2
    elif np.any(potential_fault):
        status_holder_V.warning("Potential fault detected.")
        status_holder_I.warning("Potential fault detected.")
        await send_message({
            'to_app': 'app_b',
            'message': "A Minor Fault Has Been Detected in Substation A. Please Assess the Situation"
        })
        malinga = 1
    else:
        status_holder_V.success("No faults or abnormal status detected.")
        status_holder_I.success("No faults or abnormal status detected.")
        await send_message({
            'to_app': 'app_b',
            'message': "Substation A is Working Fine"
        })
        malinga = 0

    response = await receive_message()
    messages = response.get('messages', [])
    if messages:
        latest_message = messages[-1]  # Get the most recent message
        if latest_message == "Substation B is Working Fine" and malinga == 0:
            status_received.success(latest_message)
            image_place.image(r"SUB-B.gif")
        elif latest_message == "Substation B is Working Fine":
            status_received.warning("**WARNING**")
            image_place.image(r"SUB-B-F.gif")
        elif latest_message == "Critical fault detected in Substation B, initiating emergency trip commands.":
            status_received.error(latest_message)
            image_place.image(r"SUB-B-F.gif")
            if not ohoh:
             pop_up_warning()
             ohoh = True
        else:
            status_received.warning(latest_message)
            image_place.image(r"SUB-B-F.gif")
            if not ohoh:
             pop_up_warning()
             ohoh = True
    else:
       image_place.image(r"SUB-B.gif")
       status_received.error("Error In Connection")

# AI71_API_KEY = "aai71-api-eeceb83d-053e-4526-89f6-d877507dea44"
# client = AI71(AI71_API_KEY)

def save_report_to_text_file(report, file_path):
    with open(file_path, 'w') as file:
        file.write(report)

# Function to create system prompt for LLM
def create_system_prompt(data):
    return f"""You are an advanced AI assistant specializing in power system analysis. Your task is to generate a detailed report based on the instantaneous values of various power system parameters. Analyze each parameter, compare it to standard ranges, and provide insights on the system's health and stability.

The current values of the power system parameters are as follows:

- RMS Voltage (Va, Vb,Vc): {data['va_rms']:.2f} V, {data['vb_rms']:.2f} V, {data['vc_rms']:.2f} V
- RMS Current (Ia, Ib, Ic): {data['ia_rms']:.2f} A, {data['ib_rms']:.2f} A, {data['ic_rms']:.2f} A
- Frequency: {data['avg_frequency']:.2f} Hz
- Rate of Change of Frequency (ROCOF): {data['avg_rocof']:.4f} Hz/s
- Total Apparent Power: {data['avg_active_power']:.2f} VA
- Total Reactive Power: {data['avg_reactive_power']:.2f} VAR
- Total Real Power: {data['real_power']:.2f} W
- Power Factor: {data['Power_Factor_da']:.2f}
- Sequence Components:
  - Positive Sequence: {data['I1']:.4f} A
  - Negative Sequence: {data['I2']:.4f} A
  - Zero Sequence: {data['I0']:.4f} A
- Top 5 Harmonics for each phase:
  Phase A: {data['top_harmonics_a']}
  Phase B: {data['top_harmonics_b']}
  Phase C: {data['top_harmonics_c']}
- Wavelet Entropy:
  Phase A: {data['wavelet_entropy_a']:.4f}
  Phase B: {data['wavelet_entropy_b']:.4f}
  Phase C: {data['wavelet_entropy_c']:.4f}
- Instability Score: {data['Stability_da']:.4f}

Based on these values, generate a comprehensive report addressing the following points:

1. Overall System Health: Provide a general assessment of the power system's condition.

2. Voltage Analysis:
   - Evaluate the balance between phases.
   - Comment on any deviations from the nominal voltage (typically 230V for low voltage systems).

3. Current Analysis:
   - Assess the balance between phases.
   - Comment on any unusual current levels or imbalances.

4. Frequency and ROCOF:
   - Analyze the frequency stability.
   - Interpret the ROCOF value and its implications for system stability.

5. Power Analysis:
   - Evaluate the relationship between apparent, reactive, and real power.
   - Comment on the power factor and its implications for system efficiency.

6. Sequence Components:
   - Interpret the positive, negative, and zero sequence components.
   - Discuss any implications for system balance and potential faults.

7. Harmonic Analysis:
   - Identify significant harmonics in each phase.
   - Discuss potential sources and impacts of these harmonics.

8. Wavelet Analysis:
   - Interpret the wavelet entropy values for each phase.
   - Discuss what these values indicate about the signal complexity and potential disturbances.

9. Stability Assessment:
   - Analyze the instability score.
   - Provide insights into the overall stability of the system.
   - The System is Stable if the Stability Score is between 0.95 - 1.05 even if it slightly varies from this range it is unstable.

10. Recommendations:
    - Suggest any immediate actions or further investigations based on the analysis.
    - Propose potential improvements or maintenance activities.

11. Comparative Analysis:
    - If possible, compare the current values to historical data or industry standards.

12. Future Predictions:
    - Based on the current state, provide insights into potential future behavior of the system.

If the Current is unbalance like for example (96.57 A, 10.25 A, 10.36 A) then it means that the system is experiencing a fault so mention that.

Ensure your report is clear, concise, and accessible to both technical and non-technical readers. Use technical terms where appropriate, but provide explanations for complex concepts. Your analysis should help operators and engineers make informed decisions about the power system's operation and maintenance.

Do not ever return None Values for Comments
"""

def call_falcon_api(prompt):
    print("\n"*10+"Started...")
    GOOGLE_API_KEY = "AIzaSyAIbZ7nwld9Je88p2BzNPd-0j1_L_qZRTc"
    genai.configure(api_key=GOOGLE_API_KEY)
    model = genai.GenerativeModel('gemini-pro')
    response = model.generate_content(prompt)
    print("\n"*10+"Ended...")
    print(response.text)
    return response.text

def run_llm_in_thread(data,result_queue):
    import streamlit as st
    system_prompt = create_system_prompt(data)
    report = call_falcon_api(system_prompt)
    print(report)
    # file_path = 'report.txt'
    # save_report_to_text_file(report, file_path)
    html_report = create_html_report(report)
    # Save HTML report
    file_path = 'Substation_B_report.html'
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(html_report)
    print("\n"*10+"Sucess")
    result_queue.put(report)
    print(result_queue.empty())

# Constants
f_fundamental = 50  # Fundamental frequency (Hz)
V_rms = 230  # RMS voltage (V)
I_rms = 10  # RMS current (A)
samples_per_second = 2400  # Sampling rate
timestep = 1 / samples_per_second
num_harmonics = 32
#buffer_size = 3200
pf = 0.9

stability_scores = []
stability_timestamps = []

normal_harmonics_I = {
        3: (1.8, 2.2),  # Range for 3rd harmonic
        5: (0.5, 0.6),  # Range for 5th harmonic
        7: (0.3, 0.4),  # Range for 7th harmonic
        11: (0.2, 0.3),  # Range for 11th harmonic
        13: (0.05, 0.1)  # Range for 13th harmonic
    }

def get_normal_harmonics():
    if test_case_2:
        return {
            3: (20, 30),  # Range for 3rd harmonic
            5: (10, 15),  # Range for 5th harmonic
            7: (5, 10),  # Range for 7th harmonic
            11: (2, 5),  # Range for 11th harmonic
            13: (0.1, 1)  # Range for 13th harmonic
        }
    else:
        return {
            3: (1.8, 2.2),  # Range for 3rd harmonic
            5: (0.5, 0.6),  # Range for 5th harmonic
            7: (0.3, 0.4),  # Range for 7th harmonic
            11: (0.2, 0.3),  # Range for 11th harmonic
            13: (0.05, 0.1)  # Range for 13th harmonic
        }


## Stability Score Weightage
w1_Current = 0.3
w2_Voltage = 0.2
w3_Frequency = 0.3
w4_Power_factor = 0.2

## Acceptable Limits
acceptable_current = I_rms
acceptable_voltage = V_rms
acceptable_frequency = f_fundamental 
acceptable_power_factor = pf 

def Instability_Score (Current,Voltage,Frequency,Power_Factor):
   # Calculate the stability score based on the given parameters
   Instability_Score_for_System = w1_Current*(Current/acceptable_current) + w2_Voltage*(Voltage/acceptable_voltage) + w3_Frequency*(Frequency/acceptable_frequency) + w4_Power_factor*(Power_Factor/acceptable_power_factor)
   return Instability_Score_for_System

######################################

##Tracer Functions##
def generate_waveform_voltage_normal(t, rms_value, phase_shift=0):
   # np.random.seed(0)
    waveform_N = rms_value * np.sqrt(2) * np.sin(2 * np.pi * f_fundamental * t + phase_shift) + np.random.uniform(0, 5)
    normal_harmonics = get_normal_harmonics()
    for harmonic, magnitude_range in normal_harmonics.items():
        # Randomly select a magnitude within the range
        magnitude = np.random.uniform(*magnitude_range)
        waveform_N += ((magnitude / 100) * rms_value * np.sqrt(2) *
                     np.sin(2 * np.pi * harmonic * f_fundamental * t + harmonic * phase_shift))

    return waveform_N

def generate_waveform_current_normal(t, rms_value, phase_shift=0):
    # np.random.seed(0)
    waveform_N = rms_value * np.sqrt(2) * np.sin(2 * np.pi * f_fundamental * t + phase_shift) + np.random.uniform(0,5)
    for harmonic, magnitude_range in normal_harmonics_I.items():
        magnitude = np.random.uniform(*magnitude_range)
        waveform_N += ((magnitude / 100) * rms_value * np.sqrt(2) * 
                     np.sin(2 * np.pi * harmonic * f_fundamental * t + harmonic * phase_shift))
    return waveform_N

#########################################################
def generate_waveform_current(t, rms_value, phase_shift=0):
   # np.random.seed(0)
    waveform = rms_value * np.sqrt(2) * np.sin(2 * np.pi * f_fundamental * t + phase_shift) + np.random.uniform(0,5)
    for harmonic, magnitude_range in normal_harmonics_I.items():
        magnitude = np.random.uniform(*magnitude_range)
        waveform += ((magnitude / 100) * rms_value * np.sqrt(2) * 
                     np.sin(2 * np.pi * harmonic * f_fundamental * t + harmonic * phase_shift))
    return waveform

def generate_waveform_voltage(t, rms_value, phase_shift=0):
   # np.random.seed(0)
    waveform = rms_value * np.sqrt(2) * np.sin(2 * np.pi * f_fundamental * t + phase_shift) + np.random.uniform(0, 5)
    normal_harmonics = get_normal_harmonics()
    for harmonic, magnitude_range in normal_harmonics.items():
        # Randomly select a magnitude within the range
        magnitude = np.random.uniform(*magnitude_range)
        waveform += ((magnitude / 100) * rms_value * np.sqrt(2) *
                     np.sin(2 * np.pi * harmonic * f_fundamental * t + harmonic * phase_shift))

    return waveform

#########################################################

def perform_wavelet_transform(voltage, sample_rate, f_fundamental=50, num_harmonics=32):
    #Focus on fundamental frequency and its harmonics
    freqs = np.arange(1, num_harmonics + 1) * f_fundamental
    scales = pywt.frequency2scale('cmor1-1.5', freqs / sample_rate)
    coefficients, _ = pywt.cwt(voltage, scales, 'cmor1-1.5')
    return coefficients, freqs

def calculate_wavelet_energy(coefficients):
    return np.mean(np.abs(coefficients)**2, axis=1)

def calculate_wavelet_entropy(coefficients):
    energy = calculate_wavelet_energy(coefficients)
    total_energy = np.sum(energy)
    if total_energy == 0:
        return 0
    normalized_energy = energy / total_energy
    entropy = -np.sum(normalized_energy * np.log2(normalized_energy + 1e-12))
    return entropy

def Sequence_Component_calculator(Ia, Ib, Ic):
    # Sequence component operator
    a = cmath.rect(1, 2 * cmath.pi / 3)  # e^(j120 degrees)
    # Calculate sequence components
    I1 = (Ia + a * Ib + a**2 * Ic) / 3
    I2 = (Ia + a**2 * Ib + a * Ic) / 3
    I0 = (Ia + Ib + Ic) / 3

    return abs(I1), abs(I2), abs(I0)

def generate_frequency(t, base_frequency=f_fundamental):
    frequency_variation = np.sin(2 * np.pi * 0.1 * t) * 0.005 * base_frequency
    return base_frequency + frequency_variation

def generate_rocof(frequencies):
    return np.diff(frequencies) / timestep

def calculate_power(va, ia, vb, ib, vc, ic, pf):
    # Calculate active power using power factor
    active_power_da = va * ia + vb * ib + vc * ic
    return active_power_da

def calculate_reactive_power(va, ia, vb, ib, vc, ic, pf):
    # Calculate reactive power using power factor
    #reactive_power_da = va * ia * np.sqrt(1 - pf**2) + vb * ib * np.sqrt(1 - pf**2) + vc * ic * np.sqrt(1 - pf**2)
    θ = math.acos(pf)
    ac_power = calculate_power(va, ia, vb, ib, vc, ic, pf)
    mul_fac = math.sin(θ)
    reactive_power_da = ac_power * mul_fac
    return reactive_power_da

def calculate_real_power(va, ia, vb, ib, vc, ic, pf):
    # Calculate reactive power using power factor
    ac_power = calculate_power(va, ia, vb, ib, vc, ic, pf)
    real_power_da = ac_power * pf
    return real_power_da


def calculate_harmonics(voltage, samples_per_second, f_fundamental, num_harmonics):
    """Calculates the harmonics of a voltage signal using FFT."""
    # Calculate FFT
    fft_result = np.fft.fft(voltage)
    n = len(voltage)
    fft_result = np.abs(fft_result[:n//2])  # Take positive frequencies only
    
    # Normalize by length of the signal and multiply by 2 (except DC and Nyquist)
    fft_result /= n
    fft_result[1:n//2-1] *= 2
    
    # Calculate frequency resolution
    freq_resolution = samples_per_second / n
    
    # Extract harmonic magnitudes
    harmonic_indices = np.round(np.arange(1, num_harmonics + 1) * f_fundamental / freq_resolution).astype(int)
    harmonic_indices = np.clip(harmonic_indices, 0, len(fft_result) - 1)  # Clip indices to valid range
    harmonic_magnitudes = fft_result[harmonic_indices]
    
    # Normalize magnitudes to range 0 to 1
    max_magnitude = np.max(harmonic_magnitudes)
    if (max_magnitude > 0):
        harmonic_magnitudes /= max_magnitude

    return harmonic_magnitudes

@st.dialog(title="Harmonic Handbook",width='large')
def harmonic_handbook():
    st.markdown("""
    **:red-background[Note:]** :orange-background[Remember that a comprehensive analysis often requires further investigation and expert advice.]

    | Harmonic Order | Magnitude Range | Condition | Description | Corrective Actions |
    |---|---|---|---|---|
    | 1 | 1.0 | Normal | Fundamental | Monitor |
    | 2 | 0.05-0.15 | Normal | Non-linear loads | Use filters |
    | 3 | 0.05-0.2 | Normal | Overheating | Check transformer; consider filters |
    | 4 | 0.02-0.1 | Normal | Less significant | Generally not a concern |
    | 5 | 0.1-0.3 | LL Fault | Rises in faults | Investigate; apply filters |
    | 6 | 0.02-0.1 | Normal | Certain loads | Assess load; use filters if persistent |
    | 7 | 0.1-0.3 | LLL Fault | Increases in faults | Investigate; implement filters |
    | 8 | 0.01-0.05 | Normal | Less common | Monitor; typically not problematic |
    | 9 | 0.05-0.1 | LL Fault | Rises in faults | Check system; use filters |
    | 10 | 0.01-0.05 | Normal | Lower levels | Generally not a concern |
    | 11 | 0.05-0.2 | SLG Fault | Indicative of faults | Investigate; apply filters |
    | 12 | 0.01-0.05 | Normal | Negligible | Monitor; not usually a concern |
    | 13 | 0.05-0.1 | LLG Fault | Increases in faults | Investigate; apply filters |
    """)
###################
def generate_three_phase_data():
    global test_case_1
    global test_case_2

    t = np.linspace(0, 1, samples_per_second, endpoint=False)
    
    va = generate_waveform_voltage(t, V_rms, 0)
    vb = generate_waveform_voltage(t, V_rms, -2 * np.pi / 3)
    vc = generate_waveform_voltage(t, V_rms, 2 * np.pi / 3)
    
    ia = generate_waveform_current(t, I_rms, 0)
    if test_case_1:
     random_addition_I1 = np.random.uniform(90, 95, size=ia.shape)
     ia += random_addition_I1
    ib = generate_waveform_current(t, I_rms, -2 * np.pi / 3)
    ic = generate_waveform_current(t, I_rms, 2 * np.pi / 3)
    

    va_tracer = generate_waveform_voltage_normal(t,V_rms,0)
    vb_tracer = generate_waveform_voltage_normal(t, V_rms, -2 * np.pi / 3)
    vc_tracer = generate_waveform_voltage_normal(t, V_rms, 2 * np.pi / 3)

    ia_tracer = generate_waveform_current_normal(t, I_rms, 0)
    ib_tracer = generate_waveform_current_normal(t, I_rms, -2 * np.pi / 3)
    ic_tracer = generate_waveform_current_normal(t, I_rms, 2 * np.pi / 3)

    
    frequencies = generate_frequency(t)
    rocof = generate_rocof(frequencies)
    #power = calculate_power(va, ia, vb, ib, vc, ic)
    
    return va, vb, vc, ia, ib, ic, va_tracer, vb_tracer, vc_tracer, ia_tracer, ib_tracer, ic_tracer,frequencies, rocof

# Streamlit UI setup
st.set_page_config(page_title="Substation B RAG-MAS", layout="wide", page_icon="🖥️")
st.title("⚡️Resilient & Adaptive Grid Control using Multi-Agent Systems⚡️")
st.subheader(" ",divider='orange')

tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs(["🏠 Overview", "🔍 Sequence Components", "📈 Phase Analysis", "⚖️ Stability", "🔌Load Managment", "⚡️Outage Recommendations", "🏥System Health"])
with tab1:
    boundeded = st.container(border=True)
    col112, col122, col132 = boundeded.columns([1,3,1])
    with col112:
        st.subheader("Sys. Params 🖥️",divider="orange")
        hola2 = st.container(border=True)
        as11, as12 ,as13 = hola2.columns([0.02, 1, 0.06])
        with as12:
            with st.container(border=True):
             frequency_placeholder_r = st.empty()
            with st.container(border=True):
             rocof_placeholder_r = st.empty()
            with st.container(border=True):
             Power_Factor = st.empty()

            with st.container(border=True):
             power_placeholder_r = st.empty()
            with st.container(border=True):
             reactive_power_placeholder_r = st.empty()
            with st.container(border=True):
             real_power_place = st.empty()
            
        with as11:
           st.write(" ")
        with as13:
           st.write(" ")
    with col122:
            st.subheader("Substation B Layout 🔎",divider="orange")
            dank_da = st.container(border=True)
            adadad1,adadad2 = dank_da.columns([1,0.7])
            with adadad1:
               st.warning("The Single-line diagram offers system overview.")
            with adadad2:
             st.write(" ")
             timestamp_placeholder = st.empty()
            mur1,mur2,mur3 = st.columns([1,1,2])
            with mur1:
                st.markdown("***Voltage Status:***")
                status_holder_V = st.empty()
            with mur2:
                st.markdown("***Current Status:***")
                status_holder_I = st.empty()
            with mur3:
                st.markdown("***Situation:***")
                status_received = st.empty()
            image_place = st.empty()

    with col132:
        st.subheader("V & I Readings ⚡",divider="orange")
        hola1 = st.container(border=True)
        cc11, cc12, cc13 = hola1.columns([0.02, 1, 0.06])
        with cc12:
            with st.container(border=True):
             voltage_readings_A_r = st.empty()
            with st.container(border=True):
             voltage_readings_B_r = st.empty()
            with st.container(border=True):
             voltage_readings_C_r = st.empty()

            with st.container(border=True):
             current_readings_A_r = st.empty()
            with st.container(border=True):
             current_readings_B_r = st.empty()
            with st.container(border=True):
             current_readings_C_r = st.empty()
        with cc11:
         st.write(" ")
        with cc13:
         st.write(" ")
    st.subheader(" ",divider='orange')

with tab2:
    bounded = st.container(border=True)
    with bounded:
        st.subheader("Dynamic Sequence Component Analysis 🎯",divider="orange")
    col12, col22 = bounded.columns([0.7,1])
    with col12:
        st.write(" ")
        st.write(" ")
        jojo = st.container(border=True)
        aaa1, aaa2, aaa3 = jojo.columns(3)
        with aaa1:
            sequence_placeholder_Pos = st.empty()
        with aaa2:
            sequence_placeholder_Neg = st.empty()
        with aaa3:
            sequence_placeholder_Zero = st.empty()
        with st.container(border=True):
            st.subheader("Diagnostic Tool 🛠")
            st.warning("This model offers a rough estimate of fault types. Exercise prudence when interpreting its results.")
            quel1,quel2 = st.columns([0.6,2])
            with quel1:
                st.write(" ")
                st.markdown("***Model Output:***")
            with quel2:
                ml_seq_place = st.empty()
    with col22:
        Sequence_Component_fig = go.Figure()
        Sequence_Component_fig.add_trace(go.Bar(y=[], name='Positive Sequence Component'))
        Sequence_Component_fig.add_trace(go.Bar(y=[], name='Negative Sequence Component'))
        Sequence_Component_fig.add_trace(go.Bar(y=[], name='Zero Sequence Component'))
        Sequence_Component_fig.update_layout(title='Sequence Component Analysis')
        Sequence_Component_chart = st.plotly_chart(Sequence_Component_fig, use_container_width=True)
    st.subheader(" ",divider='orange')

        
with tab3: 
 with st.container(border=True):
  with st.container(border=True):
    st.subheader("Phase A Dynamic Harmonic Analysis 📊",divider="orange")
    bobaba = st.container(border=True)
    with bobaba:
        st.markdown("***Top 5 Harmonic Magnitudes:***")
    ewew1,ewew2,ewew3,ewew4,ewew5 = bobaba.columns(5)
    with ewew1:
        harmonic_placeholder_1_a = st.empty()
    with ewew2:
        harmonic_placeholder_2_a = st.empty()
    with ewew3:
        harmonic_placeholder_3_a = st.empty()
    with ewew4:
        harmonic_placeholder_4_a = st.empty()
    with ewew5:
        harmonic_placeholder_5_a = st.empty()
    qwe1,qwe2 = st.columns([1,0.8])
    with qwe1:
        harmonic_fig_a = go.Figure()
        for i in range(10):
            harmonic_fig_a.update_layout(title='Harmonics Magnitude (Phase A)')
            harmonic_fig_a.add_trace(go.Bar(name=f'Harmonic {i+1}', y=[]))

        harmonic_chart_a = st.plotly_chart(harmonic_fig_a, use_container_width=True) 
        quin1,quin2 = st.columns([2,1])
        with quin1:
            st.warning("For a more in-depth understanding, please consult the Harmonic Handbook.")
        with quin2:
         if st.button("Handbook",key="1_v"):
            harmonic_handbook()
    with qwe2:
        wavelet_plot_placeholder_a = st.empty()
        stott1,stott2 = st.columns([1,2])
        with stott1:
         st.write(" ")
         entropy_metric_a = st.empty()
        with stott2:
         st.markdown("""- **Wavelet energy** measures the distribution of total energy in a signal across different frequencies.
- **Wavelet entropy** quantifies the complexity or randomness of the signal.
""")

  with st.container(border=True):
    st.subheader("Phase B Dynamic Harmonic Analysis 📊",divider="orange")
    goosebumpys = st.container(border=True) 
    with goosebumpys:
        st.markdown("***Top 5 Harmonic Magnitudes:***")   
    ewew11,ewew12,ewew13,ewew14,ewew15 = goosebumpys.columns(5)
    with ewew11:
        harmonic_placeholder_1_b = st.empty()
    with ewew12:
        harmonic_placeholder_2_b = st.empty()
    with ewew13:
        harmonic_placeholder_3_b = st.empty()
    with ewew14:
        harmonic_placeholder_4_b = st.empty()
    with ewew15:
        harmonic_placeholder_5_b = st.empty()
        
    qwe11,qwe12 = st.columns([1,0.8])
    with qwe11:
        harmonic_fig_b = go.Figure()
        for i in range(10):
            harmonic_fig_b.add_trace(go.Bar(name=f'Harmonic {i+1}', y=[]))
            harmonic_fig_b.update_layout(title='Harmonics Magnitude (Phase B)')
        harmonic_chart_b = st.plotly_chart(harmonic_fig_b, use_container_width=True) 
    with qwe12:
        wavelet_plot_placeholder_b = st.empty()
        entropy_metric_b = st.empty()
  with st.container(border=True):
    st.subheader("Phase C Dynamic Harmonic Analysis 📊",divider="orange")
    gogogaga = st.container(border=True)
    with gogogaga:
        st.markdown("***Top 5 Harmonic Magnitudes:***")
    ewew111,ewew112,ewew113,ewew114,ewew115 = gogogaga.columns(5)
    with ewew111:
        harmonic_placeholder_1_c = st.empty()
    with ewew112:
        harmonic_placeholder_2_c = st.empty()
    with ewew113:
        harmonic_placeholder_3_c = st.empty() 
    with ewew114:
        harmonic_placeholder_4_c = st.empty()
    with ewew115:
        harmonic_placeholder_5_c = st.empty()

    qwe111,qwe112 = st.columns([1,0.8])
    with qwe111:
        harmonic_fig_c = go.Figure()
        for i in range(10):
            harmonic_fig_c.add_trace(go.Bar(name=f'Harmonic {i+1}', y=[]))
            harmonic_fig_c.update_layout(title='Harmonics Magnitude (Phase C)')
        harmonic_chart_c = st.plotly_chart(harmonic_fig_c, use_container_width=True)
    with qwe112:
        wavelet_plot_placeholder_c = st.empty()
        entropy_metric_c = st.empty()
    st.subheader(" ",divider='orange')

with tab4:
   dadada = st.container(border=True)
   with dadada:
    st.subheader("Stability Score Calculator ⚖️",divider="orange")
   fed1,fed2 = dadada.columns([1,2])
   with fed1:
      st.markdown("***Metrics to Calculate Stability Score:***")
      uwuw = st.container(border=True)
      hoho1,hoho2 = uwuw.columns(2)
      with hoho1:
       V_for_s = st.empty()
       C_for_s = st.empty()
      with hoho2:
       F_for_s = st.empty()
       P_for_s = st.empty()
      st.divider()
      gad1,gad2 = st.columns([1.1,1.2])
      with gad1:
          st.markdown("***System Health:🔰***")
          score_ma = st.empty()
      with gad2:
       st.write(" ")
       st.write(" ")
       with st.container(border=True):
        deez_score = st.empty()
   with fed2:
       Stability_plot_holder = st.empty()
   st.subheader(" ",divider='orange')

with tab5:
   st.header(":orange-background[🚧 Developer Notice 🪧]",divider='orange')
   st.markdown("""
### **Exciting Things Are Coming...🫣**
""")
   st.info("**Anticipated Release: Phase 2.0**",icon="💡")
   st.markdown("---")
   st.markdown("We appreciate your patience and can't wait to share the upcoming features! 🌟")
with tab6:
   st.header(":orange-background[🚧 Developer Notice 🪧]",divider='orange')
   st.markdown("""
### **Exciting Things Are Coming...🫣**
""")
   st.info("**Anticipated Release: Phase 3.0**",icon="💡")
   st.markdown("---")
   st.markdown("We appreciate your patience and can't wait to share the upcoming features! 🌟")
with tab7:
   st.header(":orange-background[🚧 Developer Notice 🪧]",divider='orange')
   st.markdown("""
### **Exciting Things Are Coming...🫣**
""")
   st.info("**Anticipated Release: Phase 4.0**",icon="💡")
   st.markdown("---")
   st.markdown("We appreciate your patience and can't wait to share the upcoming features! 🌟")

st.sidebar.header("Test Cases:",divider='blue')
if st.sidebar.button("Test Case 1 - Fault"):
   test_case_1 = True
if st.sidebar.button("Test Case 2 - Harmonic Analysis"):
   test_case_2 = True
st.sidebar.success("Test Case - 3: Normal Operations")
st.sidebar.success("Test Case - 4: Peer-to-Peer Communication")
st.sidebar.success("Test Case - 5: AI Report Generation")

async def stream_data():
    await initialize_session()
    llm_thread = None
    result_queue = queue.Queue()
    try:
     while True:
        global GOGO
        global iteration_count,reset_threshold,bless,blessed
        global i
        global stability_scores, stability_timestamps
        va, vb, vc, ia, ib, ic, va_tracer, vb_tracer, vc_tracer, ia_tracer, ib_tracer, ic_tracer,frequencies, rocof = generate_three_phase_data()
        print(len(va))

        va_rms = np.sqrt(np.mean(np.square(va)))
        vb_rms = np.sqrt(np.mean(np.square(vb)))
        vc_rms = np.sqrt(np.mean(np.square(vc)))
        ia_rms = np.sqrt(np.mean(np.square(ia)))
        ib_rms = np.sqrt(np.mean(np.square(ib)))
        ic_rms = np.sqrt(np.mean(np.square(ic)))

        va_s = np.array(va)
        vb_s = np.array(vb)
        vc_s = np.array(vc)
        va_tracer_s = np.array(va_tracer)
        vb_tracer_s = np.array(vb_tracer)
        vc_tracer_s = np.array(vc_tracer)

        ia_s = np.array(ia)
        ib_s = np.array(ib)
        ic_s = np.array(ic)
        ia_tracer_s = np.array(ia_tracer)
        ib_tracer_s = np.array(ib_tracer)
        ic_tracer_s = np.array(ic_tracer)

        thresholds_V = 30
        thresholds_C = 50

        va_stalker = abs(va_s-va_tracer_s)
        vb_stalker = abs(vb_s-vb_tracer_s)
        vc_stalker = abs(vc_s-vc_tracer_s)
        max_stalker_V = np.maximum(np.maximum(va_stalker, vb_stalker), vc_stalker)

        ia_stalker = abs(ia_s-ia_tracer_s)
        ib_stalker = abs(ib_s-ib_tracer_s)
        ic_stalker = abs(ic_s-ic_tracer_s)
        max_stalker_C = np.maximum(np.maximum(ia_stalker, ib_stalker), ic_stalker)

        major_fault = (max_stalker_V > thresholds_V * 2) | (max_stalker_C > thresholds_C * 2)
        trip_command = (max_stalker_V > thresholds_V * 1.5) | (max_stalker_C > thresholds_C * 1.5)
        potential_fault = (max_stalker_V > thresholds_V) | (max_stalker_C > thresholds_C)

        await handle_fault_detection(major_fault,trip_command,potential_fault)

        avg_frequency = np.mean(frequencies)
        avg_rocof = np.mean(rocof)
        active_power = calculate_power(va_rms, ia_rms, vb_rms, ib_rms, vc_rms, ic_rms, pf)
        reactive_power = calculate_reactive_power(va_rms, ia_rms, vb_rms, ib_rms, vc_rms, ic_rms, pf)
        real_power = calculate_real_power(va_rms, ia_rms, vb_rms, ib_rms, vc_rms, ic_rms, pf)
        avg_active_power = np.mean(active_power)
        avg_reactive_power = np.mean(reactive_power)
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        timestamp_placeholder.markdown(f"**Last updated:** {current_time}")
        v_for_s_1 = (va_rms + vb_rms + vc_rms)/3
        c_for_s_2 = (ia_rms + ib_rms + ic_rms)/3
        f_for_s_3 = avg_frequency
        p_for_s_4 = np.random.uniform(0.8,0.9)

        Stability_da = Instability_Score(c_for_s_2,v_for_s_1,f_for_s_3,p_for_s_4)
        V_for_s.metric(label="System Votlage",value = f"{v_for_s_1:.4f} V",delta="Weightage 0.2")
        C_for_s.metric(label="System Current",value = f"{c_for_s_2:.4f} A",delta="Weightage 0.3")
        F_for_s.metric(label="System Frequency",value = f"{f_for_s_3:.4f} Hz",delta="Weightage 0.3")
        P_for_s.metric(label="System Power Factor",value = f"{p_for_s_4:.4f}",delta="Weightage 0.2")
        deez_score.metric(label="Stability Score",value = f"{Stability_da:.4}")
        if 0.95 < Stability_da < 1.05:
         score_ma.success("System is Stable and Functional")
        else:
         score_ma.warning("System Instability Detected")
        
        current_time = datetime.now()
        stability_scores.append(Stability_da)
        stability_timestamps.append(current_time)
        if len(stability_scores) > 60:
            stability_scores = stability_scores[-60:]
            stability_timestamps = stability_timestamps[-60:]
        
        # Create the main scatter plot for Stability Score
        main_trace = go.Scatter(
            x=stability_timestamps, 
            y=stability_scores, 
            mode='lines+markers',
            name='Stability Score',  # Add name for the main trace
            line=dict(color='blue')
        )

        # Create lower threshold line
        line_1 = go.Scatter(
            x=[min(stability_timestamps), max(stability_timestamps)],
            y=[0.95, 0.95],
            mode="lines",
            line=dict(color="red", dash="dash"),
            name="Lower Threshold"
        )

        # Create upper threshold line
        line_2 = go.Scatter(
            x=[min(stability_timestamps), max(stability_timestamps)],
            y=[1.05, 1.05],
            mode="lines",
            line=dict(color="red", dash="dash"),
            name="Upper Threshold"
        )

        # Create the figure with all traces
        Stability_da_da = go.Figure(data=[main_trace, line_1, line_2])

        # Update layout
        Stability_da_da.update_layout(
            title='Stability Monitor', 
            yaxis=dict(range=[0.90, 1.3]),
            xaxis_title='Timestamp', 
            yaxis_title='Stability Score',
            showlegend=True
        )

        # Display the chart
        Stability_plot_holder.plotly_chart(Stability_da_da, use_container_width=True)
        frequency_placeholder_r.metric(label="Frequency (Hz)", value=f"{avg_frequency:.2f} Hz")
        rocof_placeholder_r.metric(label="ROCOF (Hz/s)", value=f"{avg_rocof:.2f} Hz/s")
        power_placeholder_r.metric(label="Total Apparent Power  (VA)", value=f"{avg_active_power:.1f} VA")
        reactive_power_placeholder_r.metric(label="Total Reactive Power (VAR)", value=f"{avg_reactive_power:.1f} VAR")
        real_power_place.metric(label="Total Real Power (W)",value=f"{real_power:.1f} W")

        voltage_readings_A_r.metric(label="RMS Va (V)", value=f"{va_rms:.2f} V")
        voltage_readings_B_r.metric(label="RMS Vb (V)", value=f"{vb_rms:.2f} V")
        voltage_readings_C_r.metric(label="RMS Vc (V)", value=f"{vc_rms:.2f} V")
        current_readings_A_r.metric(label="RMS Ia (A)", value=f"{ia_rms:.2f} A")
        current_readings_B_r.metric(label="RMS Ib (A)", value=f"{ib_rms:.2f} A")
        current_readings_C_r.metric(label="RMS Ic (A)", value=f"{ic_rms:.2f} A")
        
        Power_Factor_da = np.random.uniform(0.7,0.9)
        Power_Factor.metric(label="Power Factor (PF)",value=f"{Power_Factor_da:.2f}")
        # Calculate sequence components
        Ia1 = cmath.rect(ia_rms, 0)
        Ib2 = cmath.rect(ib_rms, -2 * np.pi / 3)
        Ic3 = cmath.rect(ic_rms, 2 * np.pi / 3)
        I1, I2, I0 = Sequence_Component_calculator(Ia1,Ib2,Ic3)
        max_sequence = max(I1, I2, I0)

        if max_sequence > 0:
            I1 /= max_sequence
            I2 /= max_sequence 
            I0 /= max_sequence 
        # # I1 /= I_rms
        # # I2 /= I_rms
        # # I0 /= I_rms

        sequence_placeholder_Pos.metric(label="Positive Sequence (A)", value=f"{I1:.4f}")
        sequence_placeholder_Neg.metric(label="Negative Sequence (A)", value=f"{I2:.4f}")
        sequence_placeholder_Zero.metric(label="Zero Sequence (A)", value=f"{I0:.4f}")

        model = joblib.load('fault_classifier_model.pkl')
        input_data = np.array([[I1, I2, I0]]) 
        prediction = model.predict(input_data)
        label_mapping = {
            0: "Nominal",
            1: "SLG",
            2: "LL",
            3: "LLG",
            4: "LLL",
            5: "LLLG",
            6: "Open_Conductor"
        }
        fault_type = label_mapping.get(prediction[0], "Unknown Fault Type")
        if fault_type == "Nominal":
         ml_seq_place.success("System is operating normally.")
        else:
         ml_seq_place.error(f"Potential {fault_type} fault is detected")
        # Update Sequence Components Bar Chart
        Sequence_Component_fig.data[0].y = [I1]
        Sequence_Component_fig.data[1].y = [I2]
        Sequence_Component_fig.data[2].y = [I0]
        Sequence_Component_chart.plotly_chart(Sequence_Component_fig, use_container_width=True)

        # Calculate harmonics for A
        harmonic_magnitudes_a = calculate_harmonics(np.array(va), samples_per_second, f_fundamental, num_harmonics)
        top_harmonics_indices_a = np.argsort(harmonic_magnitudes_a)[-10:][::-1]
        top_harmonic_magnitudes_a = harmonic_magnitudes_a[top_harmonics_indices_a]
        
        harmonic_placeholder_1_a.metric(label=f"Harmonic {top_harmonics_indices_a[0]+1} **(Fundamental Freq.)**", value=f"{top_harmonic_magnitudes_a[0]:.4f}")
        harmonic_placeholder_2_a.metric(label=f"Harmonic {top_harmonics_indices_a[1]+1}", value=f"{top_harmonic_magnitudes_a[1]:.4f}")
        harmonic_placeholder_3_a.metric(label=f"Harmonic {top_harmonics_indices_a[2]+1}", value=f"{top_harmonic_magnitudes_a[2]:.4f}")
        harmonic_placeholder_4_a.metric(label=f"Harmonic {top_harmonics_indices_a[3]+1}", value=f"{top_harmonic_magnitudes_a[3]:.4f}")
        harmonic_placeholder_5_a.metric(label=f"Harmonic {top_harmonics_indices_a[4]+1}", value=f"{top_harmonic_magnitudes_a[4]:.4f}")


        for i, idx in enumerate(top_harmonics_indices_a):
            if i == 0:
                continue
            else:
             harmonic_fig_a.data[i].x = [f"{idx+1}th Harmonic"]
             harmonic_fig_a.data[i].y = [top_harmonic_magnitudes_a[i]]

        harmonic_chart_a.plotly_chart(harmonic_fig_a, use_container_width=True)

        # Calculate harmonics for B
        harmonic_magnitudes_b = calculate_harmonics(np.array(vb), samples_per_second, f_fundamental, num_harmonics)
        top_harmonics_indices_b = np.argsort(harmonic_magnitudes_b)[-10:][::-1]
        top_harmonic_magnitudes_b = harmonic_magnitudes_b[top_harmonics_indices_b]
        
        harmonic_placeholder_1_b.metric(label=f"Harmonic {top_harmonics_indices_b[0]+1} **(Fundamental Freq.)**", value=f"{top_harmonic_magnitudes_b[0]:.4f}")
        harmonic_placeholder_2_b.metric(label=f"Harmonic {top_harmonics_indices_b[1]+1}", value=f"{top_harmonic_magnitudes_b[1]:.4f}")
        harmonic_placeholder_3_b.metric(label=f"Harmonic {top_harmonics_indices_b[2]+1}", value=f"{top_harmonic_magnitudes_b[2]:.4f}")
        harmonic_placeholder_4_b.metric(label=f"Harmonic {top_harmonics_indices_b[3]+1}", value=f"{top_harmonic_magnitudes_b[3]:.4f}")
        harmonic_placeholder_5_b.metric(label=f"Harmonic {top_harmonics_indices_b[4]+1}", value=f"{top_harmonic_magnitudes_b[4]:.4f}")

        for i, idx in enumerate(top_harmonics_indices_b):
            if i == 0:
             continue
            else:
             harmonic_fig_b.data[i].x = [f"{idx+1}th Harmonic"]
             harmonic_fig_b.data[i].y = [top_harmonic_magnitudes_b[i]]

        harmonic_chart_b.plotly_chart(harmonic_fig_b, use_container_width=True)

        # Calculate harmonics for C
        harmonic_magnitudes_c = calculate_harmonics(np.array(vc), samples_per_second, f_fundamental, num_harmonics)
        top_harmonics_indices_c = np.argsort(harmonic_magnitudes_c)[-10:][::-1]
        top_harmonic_magnitudes_c = harmonic_magnitudes_c[top_harmonics_indices_c]
        
        harmonic_placeholder_1_c.metric(label=f"Harmonic {top_harmonics_indices_c[0]+1} **(Fundamental Freq.)**", value=f"{top_harmonic_magnitudes_c[0]:.4f}")
        harmonic_placeholder_2_c.metric(label=f"Harmonic {top_harmonics_indices_c[1]+1}", value=f"{top_harmonic_magnitudes_c[1]:.4f}")
        harmonic_placeholder_3_c.metric(label=f"Harmonic {top_harmonics_indices_c[2]+1}", value=f"{top_harmonic_magnitudes_c[2]:.4f}")
        harmonic_placeholder_4_c.metric(label=f"Harmonic {top_harmonics_indices_c[3]+1}", value=f"{top_harmonic_magnitudes_c[3]:.4f}")
        harmonic_placeholder_5_c.metric(label=f"Harmonic {top_harmonics_indices_c[4]+1}", value=f"{top_harmonic_magnitudes_c[4]:.4f}")

        for i, idx in enumerate(top_harmonics_indices_c):
            if i == 0 :
             continue
            else:
             harmonic_fig_c.data[i].x = [f"{idx+1}th Harmonic"]
             harmonic_fig_c.data[i].y = [top_harmonic_magnitudes_c[i]]

        harmonic_chart_c.plotly_chart(harmonic_fig_c, use_container_width=True)

        time_points = np.arange(len(va)) * timestep

        coefficients_a, frequencies = perform_wavelet_transform(va, samples_per_second, f_fundamental)
        wavelet_energy_a = calculate_wavelet_energy(coefficients_a)
        wavelet_entropy_a = calculate_wavelet_entropy(coefficients_a)

        # Perform Wavelet Transform and Calculate Energy & Entropy for Phase B
        coefficients_b, frequencies = perform_wavelet_transform(vb, samples_per_second,f_fundamental)
        wavelet_energy_b = calculate_wavelet_energy(coefficients_b)
        wavelet_entropy_b = calculate_wavelet_entropy(coefficients_b)

        # Perform Wavelet Transform and Calculate Energy & Entropy for Phase C
        coefficients_c, frequencies = perform_wavelet_transform(vc, samples_per_second,f_fundamental)
        wavelet_energy_c = calculate_wavelet_energy(coefficients_c)
        wavelet_entropy_c = calculate_wavelet_entropy(coefficients_c)

        wavelet_fig_a = go.Figure(data=go.Bar(x=frequencies, y=wavelet_energy_a))
        wavelet_fig_a.update_layout(
            title='Wavelet Energy (Phase A)', 
            xaxis_title='Frequency (Hz)', 
            yaxis_title='Energy',
            xaxis_type="linear",
            yaxis_type="log",
            bargap=0.1
        )
        wavelet_plot_placeholder_a.plotly_chart(wavelet_fig_a, use_container_width=True)
        
        wavelet_fig_b = go.Figure(data=go.Bar(x=frequencies, y=wavelet_energy_b))
        wavelet_fig_b.update_layout(
            title='Wavelet Energy (Phase B)', 
            xaxis_title='Frequency (Hz)', 
            yaxis_title='Energy',
            xaxis_type="linear",
            yaxis_type="log",
            bargap=0.1
        )
        wavelet_plot_placeholder_b.plotly_chart(wavelet_fig_b, use_container_width=True)

        wavelet_fig_c = go.Figure(data=go.Bar(x=frequencies, y=wavelet_energy_c))
        wavelet_fig_c.update_layout(
            title='Wavelet Energy (Phase C)', 
            xaxis_title='Frequency (Hz)', 
            yaxis_title='Energy',
            xaxis_type="linear",
            yaxis_type="log",
            bargap=0.1
        )
        wavelet_plot_placeholder_c.plotly_chart(wavelet_fig_c, use_container_width=True)
        # Update Wavelet Entropy Metrics
        entropy_metric_a.metric(label="Wavelet Entropy (Phase A)", value=f"{wavelet_entropy_a:.4f}")
        entropy_metric_b.metric(label="Wavelet Entropy (Phase B)", value=f"{wavelet_entropy_b:.4f}")
        entropy_metric_c.metric(label="Wavelet Entropy (Phase C)", value=f"{wavelet_entropy_c:.4f}")
        if Stability_da > 1.3 and not GOGO:
            GOGO = True
            data = {
                    'va_rms': va_rms, 'vb_rms': vb_rms, 'vc_rms': vc_rms,
                    'ia_rms': ia_rms, 'ib_rms': ib_rms, 'ic_rms': ic_rms,
                    'avg_frequency': avg_frequency, 'avg_rocof': avg_rocof,
                    'avg_active_power': avg_active_power, 'avg_reactive_power': avg_reactive_power,
                    'real_power': real_power, 'Power_Factor_da': Power_Factor_da,
                    'I1': I1, 'I2': I2, 'I0': I0,
                    'top_harmonics_a': top_harmonic_magnitudes_a, 'top_harmonics_b': top_harmonic_magnitudes_b, 'top_harmonics_c': top_harmonic_magnitudes_c,
                    'wavelet_entropy_a': wavelet_entropy_a, 'wavelet_entropy_b': wavelet_entropy_b, 'wavelet_entropy_c': wavelet_entropy_c,
                    'Stability_da': Stability_da
                }
            print(data)
            if llm_thread is None or not llm_thread.is_alive():
                    llm_thread = threading.Thread(target=run_llm_in_thread, args=(data,result_queue))
                    llm_thread.start()
                    st.toast("Generating AI report...", icon="🤖")
                    #st.spinner(text='It Might take a few moments')
                    bless += 1
            if not result_queue.empty():
                    #report = result_queue.get()
                    st.toast("Report Saved Successfully....",icon="✅")

                    llm_thread.join()
        iteration_count += 1
        if bless == 1:
           blessed += 1
           if blessed == 24:
              st.toast("Report Saved Successfully....",icon="✅")

        if iteration_count >= reset_threshold:
           GOGO = False
           iteration_count = 0
        print(iteration_count)
        await asyncio.sleep(0.5)
    finally:
       await close_session()
       if llm_thread and llm_thread.is_alive():
            llm_thread.join()

if __name__ == "__main__":
    asyncio.run(stream_data())
